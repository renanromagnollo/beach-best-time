export type Season = 'verão' | 'outono' | 'inverno' | 'primavera';

export type ClimateData = {
  month: string; // número do mês: '01', '02', ..., '12'
  season: Season;
  averageTemperature: number;
  precipitation: number;
  precipitationHours: number;
  cloudCover: number;
  hourSun: number;
  windMax: number;
  score?: number;
  rating?: 'excellent' | 'good' | 'unstable' | 'bad' | 'terrible';
};

export interface ClimateDataWithYear extends ClimateData {
  year: number;
  count: number;
}
