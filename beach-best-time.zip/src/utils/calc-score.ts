import { ClimateData } from "@/domain";

export type TCalcScore = {
  score: number;
  rating: ClimateData['rating'];
  reasons: string[];
}

export function calcScore(data: ClimateData): TCalcScore {
  const {
    averageTemperature,
    cloudCover,
    hourSun,
    // month,
    precipitation,
    precipitationHours,
    season,
    windMax,
  } = data;

  const reasons: string[] = [];

  // Pesos padrão
  let weightTemp = 1;
  let weightSun = 1;
  let weightRain = 1;
  let weightCloud = 1;
  let weightWind = 1;
  const weightPrecipHours = 0.8;

  // Ajustes por estação
  switch (season) {
    case 'verão':
      weightSun = 1.5;
      weightRain = 1.2;
      weightTemp = 1.3;
      break;
    case 'inverno':
      weightSun = 1.3;
      weightCloud = 0.8;
      weightTemp = 0.8;
      break;
    case 'outono':
      weightRain = 1.2;
      weightWind = 0.9;
      break;
    case 'primavera':
      weightSun = 1.1;
      weightRain = 1.1;
      break;
  }

  // 🌡️ Temperatura ideal
  const tempScore = 10 - Math.abs(26 - averageTemperature); // ideal: 26 °C
  if (tempScore < 7) reasons.push('Temperatura fora do ideal');

  // 🌧️ Precipitação total
  const rainScore = 10 - Math.min(precipitation / 10, 10); // ideal: <20mm
  if (precipitation > 30) reasons.push('Alta precipitação');

  // ⏱️ Horas de chuva
  const rainHourScore = 10 - Math.min(precipitationHours * 2, 10); // ideal: <3h
  if (precipitationHours > 3) reasons.push('Muitas horas de chuva');

  // ☁️ Nuvens
  const cloudScore = 10 - Math.min(cloudCover / 10, 10);
  if (cloudCover > 60) reasons.push('Muita nebulosidade');

  // ☀️ Sol
  const sunScore = Math.min(hourSun / 3, 10); // 8h = nota 10
  if (hourSun < 5 * 30) reasons.push('Poucas horas de sol'); // mês com menos de 150h de sol

  // 💨 Vento
  const windScore = 10 - Math.min(windMax / 2, 10);
  if (windMax > 30) reasons.push('Vento muito forte');

  // Score final ponderado
  const totalScore =
    (tempScore * weightTemp +
      rainScore * weightRain +
      rainHourScore * weightPrecipHours +
      cloudScore * weightCloud +
      sunScore * weightSun +
      windScore * weightWind) /
    (weightTemp + weightRain + weightPrecipHours + weightCloud + weightSun + weightWind);

  let rating: ClimateData['rating'];
  if (totalScore >= 8.5) rating = 'excellent';
  else if (totalScore >= 7) rating = 'good';
  else if (totalScore >= 5.5) rating = 'unstable';
  else if (totalScore >= 4) rating = 'bad';
  else rating = 'terrible';

  return {
    score: Number(totalScore.toFixed(1)),
    rating,
    reasons,
  };
}
